#!/usr/bin/expect
set user [lindex $argv 0]
set password [lindex $argv 1]
spawn su - root -c "passwd $user"
expect {
"*New password*" {
exec sleep 1
send "$password\r"
}
}
expect {
"*Retype new password*" {
exec sleep 1
send "$password\r"
}
}
expect eof
exit

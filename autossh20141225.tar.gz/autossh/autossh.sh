#!/bin/bash

createSSH()
{
    local ip=$1
    local user=$2
    local passwd=$3
    
    echo "Create $user's ssh from local to $ip..."
    su $user -c "expect $auto_ssh_file $user@$ip $passwd" >> $log_file
    if [ "$?" != "0" ]
    then
        echo "Create $user's ssh from this node to $ip...failed"
        return 1
    fi
    echo "Create $user's ssh from local to $ip...done"
    
    #echo "Create $user's ssh from $ip to local..."
    #gen_key_file=$CUR_PATH/gen_ssh_key.exp
    #gen_key_file_tmp=/tmp/gen_ssh_key.exp
    #key_file_tmp=/tmp/tmp.key
    #su $user -c "scp $gen_key_file $user@$ip:$gen_key_file_tmp; ssh $ip \"chmod +x $gen_key_file_tmp;expect $gen_key_file_tmp\""
    #su $user -c "scp $user@$ip:~/.ssh/id_rsa.pub $key_file_tmp && cat $key_file_tmp >> ~/.ssh/authorized_keys"
    #if [ "$?" == "1" ]
    #then
    #    echo "Create $user's ssh from $ip to local...failed"
    #    continue
    #fi
    #echo "Create $user's ssh from $ip to local...done"
}

main()
{
    log_file=$CUR_PATH/ssh.log
    auto_ssh_file=$CUR_PATH/enable_auto_ssh.exp
    host_cfg=$CUR_PATH/hosts.cfg
    #igonre comment
	declare -a array
	i=1
    cat $host_cfg | grep -v '^ *#' | while read hostinfo 
    do
        ip=`echo $hostinfo | awk '{print $1}'`
        user=`echo $hostinfo | awk '{print $2}'`
        passwd=`echo $hostinfo | awk '{print $3}'`
#		array[$i]=(`echo $hostinfo | awk '{print $0}'` )
		let i++
        if [ "$ip" == "" -o "$user" == "" -o "$passwd" == "" ]
        then
            continue
        fi
	echo "ssh"
        createSSH $ip $user $passwd ~/createUserGroup.sh
done
}
CUR_PATH=$(cd `dirname $0`;pwd)
main 
exit $?

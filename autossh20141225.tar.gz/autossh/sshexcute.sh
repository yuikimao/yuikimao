#!/bin/bash
CUR_PATH=$(cd `dirname $0`;pwd)
log_file=$CUR_PATH/ssh.log
auto_ssh_file=$CUR_PATH/enable_auto_ssh.exp
host_cfg=$CUR_PATH/hosts.cfg
#igonre comment
ip=(` awk '{print $1}' $host_cfg`)
user=(` awk '{print $2}' $host_cfg`)
passwd=(` awk '{print $3}' $host_cfg`)
#bin=$(ifconfig | awk -F'addr:|Bcast' '/Bcast/{print $2}')
main()
{

echo "" > /tmp/lsblk.txt

for((i=0;i<${#ip[@]};i++));
do
echo "===========ip=${ip[i]}========"


echo -e "${ip[i]}\n" >> /tmp/lsblk.txt

ssh ${ip[i]} "su - omm -c \"gs_om -t stop;sed -i 's/DATA_BUFFER_SIZE = 14G/DATA_BUFFER_SIZE = 6G/g' /opt/gaussdb/data/data_dn1/cfg/zengine.ini;gs_om -t start\"" | xargs -i echo {} >> /tmp/lsblk.txt

echo -e "===========================\n" >> /tmp/lsblk.txt

# ssh ${ip[i]} "echo 'nameserver 7.221.190.93
# nameserver 7.221.190.144
# nameserver 10.129.3.45' >> /etc/resolv.conf"
# ssh ${ip[i]} "wget https://cmc-szver-artifactory.cmc.tools.huawei.com/artifactory/CMC-Release/certificates/HWITEnterpriseCA.crt --no-check-certificate;cp HWITEnterpriseCA.crt /etc/pki/trust/anchors/HWITEnterpriseCA.crt; update-ca-certificates;service docker restart"
# 
# #change ossadm passwd with root
#scp passchange.sh ${ip[i]}:/opt/
# ssh ${ip[i]} "ntpdate -u 10.3.23.46"
#ssh ${ip[i]} "cd /opt/;./passchange.sh ossadm Changeme_123"
##remove file or path
#ssh ${ip[i]} "rm -rf /etc/uuid/ /opt/oss"
##delete user or group
#ssh ${ip[i]} userdel ossadm; userdel dbuser;groupdel ossgroup
##transfor file to the other nodes
#scp -r /tmp/CBB.tar.gz ${ip[i]}:/tmp/CBB.tar.gz
#scp -r /opt/c60ompzip2.zip ${ip[i]}:/opt/oss/
#scp -r /opt/node ${ip[i]}:/opt/node
#scp -r /opt/node/manager/adapter/common/resmgr/nodes.json ${ip[i]}:/opt/node/manager/adapter/common/resmgr/nodes.json
##replace the file content
#ssh ${ip[i]} sed -i 's/master/slave/' /opt/node/manager/adapter/common/resmgr/nodes.json
#ssh ${ip[i]} sed -i "s/10.93.178.241/${ip[i]}/" /opt/node/manager/adapter/common/resmgr/nodes.json
#ssh ${ip[i]} "sed -i 's/192.168.128.60/${ip[i]}/' /opt/node/manager/adapter/common/resmgr/nodes.json"
#ssh ${ip[i]} "sed -i 's/exit 1/exit 0/' /opt/oss/manager/tools/agent/db/oracle/monitor_db.sh"
##change file permission or group
#ssh ${ip[i]} "chown -R ossadm.ossgroup /opt/node;chmod -R 750 /opt/node;chmod 600 /opt/node/manager/adapter/U2000/sysmt/test.zip;chmod 600 /opt/node/manager/adapter/M2000/sysmt/test.zip"
#ssh ${ip[i]} "chown ossadm.ossgroup /opt/oss/c60ompzip2.zip;chmod 750 /opt/oss/c60ompzip2.zip"
##do unzip operation in the nodes
#ssh ${ip[i]} "su  ossadm -c 'cd /opt/oss; unzip -o c60ompzip2.zip'"
#ssh ${ip[i]} "su  ossadm -c 'cd /opt/node; unzip node.zip'"
##make dir for nodes
#ssh ${ip[i]} "mkdir -p /export/home;chmod -R 755 /export/home;chown -R root:root /export/home"
##run CBB config
#ssh ${ip[i]} "cd /tmp; tar xzf CBB.tar.gz; cd rebuild/script; bash install_ipsi/install_ipsi.sh; bash config_sudo/config_sudo.sh -d /opt/sudobin/"
##mount NFS
#ssh ${ip[i]} "mkdir /opt/NFS;chown -R ossadm.ossgroup /opt/NFS"
#ssh ${ip[i]} "mount 10.67.175.68:/opt/NFS /opt/NFS"
##add group
#ssh ${ip[i]} "groupadd dbgroup;useradd -g dbgroup -m -d /home/dbuser dbuser"
##env clear up
#ssh ${ip[i]} "rm -rf /opt/node;mkdir /opt/node/"
#ssh ${ip[i]} "rm -rf /opt/node/backup/lan.tar"
#ssh ${ip[i]} "rm -rf /etc/uuid/uuid.txt"
#ssh ${ip[i]} "rm -rf /opt/oss/ /opt/sudobin/ /opt/signtool /opt/patch_manager /tmp/rebuild"
#ssh ${ip[i]} "rm -rf /etc/uuid/uuid.txt /tmp/cau* /tmp/command* /tmp/cti* /tmp/d* /tmp/e* /tmp/i* /opt/oss"
##change file format
#ssh ${ip[i]} "su  ossadm -c 'dos2unix /opt/oss/manager/tools/agent/db/oracle/*'"
##modify the operating system template
#scp -r /lib/udev/rules.d/60-persistent-storage.rules ${ip[i]}:/lib/udev/rules.d/
#scp /etc/fstab ${ip[i]}:/etc/
#scp /boot/grub/menu.lst ${ip[i]}:/boot/grub/
#scp /boot/grub/device.map ${ip[i]}:/boot/grub/
#ssh ${ip[i]} "mkinitrd;reboot"
##change hostname file
#scp -r /etc/hosts ${ip[i]}:/etc/
#ssh ${ip[i]} "sed -i 's/SZX/${ip[i]} SZX/' /etc/hosts"
#ssh ${ip[i]} "chmod 644 /etc/sysconfig/network/routes;chmod 644 /etc/HOSTNAME"
##grep spes installed or not
#ssh ${ip[i]} "ps -ef |grep spes"
##mkdir file 1G 
#ssh ${ip[i]} "su  ossadm -c 'mkdir /opt/node/backup'"
#ssh ${ip[i]} "cd /opt/node/backup;dd if=/dev/zero of=lan.tar bs=1G count=1; chown -R ossadm:ossgroup /opt/node;chmod -R 750 /opt/node/backup"
##unmount NFS
#ssh ${ip[i]} "umount 10.67.175.63:/home/NFSbackup /home/NFSbackup"
done
}
CUR_PATH=$(cd `dirname $0`;pwd)
main
echo $?
#
#
